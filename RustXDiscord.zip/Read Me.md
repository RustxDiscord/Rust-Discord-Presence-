This is very simple to run. 

1. disable windows secruity (this pops up as a virus due to its connection trough the pc to another application)
2. click the download link. drag the .zip to your desktop then extreact into a seprate folder on your desktop
3. go to the Bin file and ensure there are 2 .dll files and 2 txt files if there is not re download the file 
4. run the exe without administrator if it fails to work run it as administrator it should reset your discord and steam if completed correctly 
5. your down congrats load into your server and watch the magic happen

NOTE: IF IT DOES NOT WORK IT MAY BE OUTDATED

NOTE: If you have external virus protection turn off ALL settings that may delete the file 

